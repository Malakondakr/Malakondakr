﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Task27222.Models;

namespace Task27222.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult SignUp()
        {
            var Cities = GetCities();
            var Genders = GetGender();

            var model = new UserViewModel();

            model.Cities = GetSelectListItems(Cities);
            model.Genders = GetSelectListItems(Genders);

            return View(model);
        }

        private IEnumerable<string> GetCities()
        {
            return new List<string>
            {
                "",
                "Hyderabad",
                "Bangalore",
                "Chennai",
                "Pune"
            };
        }

        private IEnumerable<string> GetGender()
        {
            return new List<string>
            {
                "Male",
                "Female"
            };
        }
        private IEnumerable<SelectListItem> GetSelectListItems(IEnumerable<string> elements)
        {
            var selectList = new List<SelectListItem>();
            foreach (var element in elements)
            {
                selectList.Add(new SelectListItem
                {
                    Value = element,
                    Text = element
                });
            }

            return selectList;
        }

        [HttpPost]
        public IActionResult SignUp(UserViewModel modal)//MODEL BINDING
        {
            var Cities = GetCities();
            var Genders = GetGender();
            modal.Cities = GetSelectListItems(Cities);
            modal.Genders = GetSelectListItems(Genders);
            if (ModelState.IsValid)
            {
                // TO DO:
                return RedirectToAction("Index", "Home");
            }
            return View(modal);
        }
    }
}
